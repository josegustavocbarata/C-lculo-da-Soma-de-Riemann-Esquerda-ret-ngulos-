# Calculo-da-Soma-de-Riemann-Esquerda-retangulos-
Código voltado para o cálculo de integrais definidas através de sua partição em retângulos, dentro de um intervalo definido e utilizando um número "n" de partições.
